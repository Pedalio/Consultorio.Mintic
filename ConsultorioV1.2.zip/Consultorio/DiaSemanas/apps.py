from django.apps import AppConfig


class DiasemanasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DiaSemanas'
