from Ciudades.models import Ciudades
from django.contrib import admin
from Citas.models import *

# Register your models here.
admin.site.register(TipoCategoria)
admin.site.register(Especialidades)
admin.site.register(TipoProcedimiento)
admin.site.register(LugarCita)
admin.site.register(Pacientes)
admin.site.register(Medicos)
admin.site.register(Citas)
admin.site.register(Ciudades)
admin.site.register(DiaSemana)
admin.site.register(HorasCitasDiarias)
admin.site.register(tipoCita)