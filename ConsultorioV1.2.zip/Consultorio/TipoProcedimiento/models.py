from django.db import models
from Especialidades.models import *

# Create your models here.
class TipoProcedimiento(models.Model):
    #identID=models.CharField() =>pendiente
    nombre=models.CharField(max_length=300)
    especialidad=models.ForeignKey(Especialidades, on_delete=models.CASCADE)

    def __str__(self) -> str:
        return self.especialidad.nombre + " : " + self.nombre
